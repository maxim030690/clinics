<div class="container">
    <div class="row">
      <div class="col-md-12">
			[jtit_description_of_the_laboratory]
      </div>
    </div>
  </div>