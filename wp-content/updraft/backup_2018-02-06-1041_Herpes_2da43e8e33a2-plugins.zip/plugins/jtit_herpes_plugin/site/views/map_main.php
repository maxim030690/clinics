<?php
/**
 * Created by Artem Chernitsov.
 * Date: 03.01.2017
 * Time: 14:09
 */
 

?>

        
       
                <!-- lab map -->
                
                    <div id="geo-mashup">
                        <div id="map_canvas" style="width: 100%; height: 100%"></div>
                    </div>
                
            

    	
	<script type="text/javascript" src="<?php echo JTIT_URL?>assets/js/map.js"></script>
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCH41rA4F_17yMiZD_VoiwEHUZwmVnHQqI&sensor=false&callback=initialize"></script>