<script type="text/javascript" src="<?php echo JTIT_URL?>assets/js/map.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCH41rA4F_17yMiZD_VoiwEHUZwmVnHQqI&sensor=false&callback=initialize"></script>
<div id="map_canvas" style="width: 100%; height: 100%"></div>