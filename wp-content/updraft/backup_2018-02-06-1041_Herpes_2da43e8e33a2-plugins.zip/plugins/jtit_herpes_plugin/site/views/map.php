<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 26.12.2016
 * Time: 12:53
 */
require_once JTIT_PATH . 'lib' . DIRECTORY_SEPARATOR .'home_map.php';
Map_home();
//echo 'Hello world';