<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 20.12.2016
 * Time: 16:00
 */
?>

<!-- clinic locations map -->
<section class="homepage-section clinic-locations text-center" onload="loadScript()">


    <h3>54 Conveniently Located Testing Centers In <?php echo get_theme_mod('city')?></h3>
    <p>Find One Close To You</p>

    <div class="row home-baner">
        <div class="small-10 small-offset-1 columns">

            <div id="map" class="map">
                <div id="geo-mashup">
                    <div id="map_canvas" style="width: 100%; height: 100%" >
                    </div>
                </div>
            </div>
            <form class="zip-search" action="/centers-by-zip/zip" accept-charset="UTF-8" method="get"><input name="utf8" type="hidden" value="&#x2713;" />
                <input type="text" name="zipcode" id="zipcode" placeholder="Zip Code" class="zipcode-input" />
                <input type="submit" name="commit" value="Find A Lab Near You" class="find-lab button" />
            </form>

        </div>
    </div>


</section>
