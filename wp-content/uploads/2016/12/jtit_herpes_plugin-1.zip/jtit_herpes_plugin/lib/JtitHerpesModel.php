<?php

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 23.12.2016
 * Time: 15:26
 */
class JtitHerpesModel
{
    public function set_tests_prices($post){
        $option_name = 'jtit_tests' ;
        $newvalue['chlamydia'] = $post['chlamydia'];
        $newvalue['gonorrhea'] = $post['gonorrhea'];
        $newvalue['herpes_1'] = $post['herpes_1'];
        $newvalue['herpes_2'] = $post['herpes_2'];
        $newvalue['HIV_1'] = $post['HIV_1'];
        $newvalue['hepatitis_A'] = $post['hepatitis_A'];
        $newvalue['hepatitis_B'] = $post['hepatitis_B'];
        $newvalue['hepatitis_C'] = $post['hepatitis_C'];
        $newvalue['syphilis'] = $post['syphilis'];
        $newvalue['HIV_2'] = $post['HIV_2'];


        if ( get_option($option_name) ) {
            update_option($option_name, $newvalue);
        } else {
            $deprecated=' ';
            $autoload='yes';
            add_option($option_name, $newvalue, $deprecated, $autoload);
        }

    }

}