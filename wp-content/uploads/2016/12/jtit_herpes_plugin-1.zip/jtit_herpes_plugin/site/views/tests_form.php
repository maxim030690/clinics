<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 26.12.2016
 * Time: 11:28
 */

?>

<!--<div class="disease-info-section text-center light-grey-bg">-->
    <div class="disease-tests-and-pricing">
        <h4 class="text-left">Tests & Pricing <?php echo get_the_title()?></h4>
        <div class="bordered-box-content text-left">
            <p>Our doctors use a FDA-approved genital herpes test advanced enough to screen both HSV-1 (oral herpes) and HSV-2 (genital herpes) individually.  The herpes test requires a blood sample and only takes a few minutes, results in 1-2 days.</p>
            <h5>Please Select Your Test Below:</h5>

            <form class="" action="/add_test" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="&#x2713;" /><input type="hidden" name="authenticity_token" value="L1A9+e/Cwk5S0uCbSC+Y5wxi4t54T/dGa13Gy/icAqFXWYHUAeROW1SICpLVKetw++cbWm8LF3ij24BSpKWMDg==" />

                <div class="test-option">
                    <input type="radio" name="product_id" value="3" id="ten-panel-test">
                    <label for="ten-panel-test">10 Panel Comprehensive Test <span class="price">$220</span></label>
                </div><br /><br />

                <div class="test-option">
                    <input type="radio" name="product_id" value="36" id="herpes1-test">
                    <label for="herpes1-test">Herpes 1 <span class="price">$79</span></label>
                </div>

                <div class="test-option">
                    <input type="radio" name="product_id" value="69" id="herpes2-test">
                    <label for="herpes2-test">Herpes 2 <span class="price">$79</span></label>
                </div>

                <div class="test-submit text-right">
                    <input type="submit" class="get-tested-now-btn button" value="Get Tested Now" />
                </div>

            </form>
        </div>
    </div>
<!--</div>-->
