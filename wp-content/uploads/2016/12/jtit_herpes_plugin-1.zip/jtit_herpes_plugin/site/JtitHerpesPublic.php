<?php

/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 23.12.2016
 * Time: 15:37
 */
class JtitHerpesPublic
{

    private $model;
    private $view;
    private $view_path;

    public function __construct()
    {
        //view path
        $this->view_path = JTIT_PATH . 'site' . DIRECTORY_SEPARATOR . 'views' . DIRECTORY_SEPARATOR;

        //model object
        require_once JTIT_PATH . 'lib' . DIRECTORY_SEPARATOR . 'JtitHerpesModel.php';
        $this->model = new JtitHerpesModel();

        //view object
        require_once JTIT_PATH.'lib'.DIRECTORY_SEPARATOR.'JtitHerpesView.php';
        $this->view = new JtitHerpesView();

        add_shortcode('jtit_tests_form', array($this, 'jtit_print_tests_form'));
        add_shortcode('jtit_home_map', array($this, 'jtit_print_home_map'));

        add_action('wp_enqueue_scripts', array($this,'load_style'));

        if (!empty($_POST)){
            $this->check_action($_POST);
        }
    }

    public function jtit_print_tests_form(){
        $data = '';
        return $this->view->render($data, $this->view_path.'tests_form.php');
    }

    public function jtit_print_home_map(){
        $data = '';
        return $this->view->render($data, $this->view_path.'map.php');
    }

    public function load_style(){

    }

    public function check_action($post){

    }

}